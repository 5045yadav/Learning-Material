package Day10;

import java.util.Scanner;

public class Oops_Concept {
    //Variables
    int eid;
    String ename;
    String job;
    int sal;
    Scanner sc = new Scanner(System.in);
    //Methods
    void display()
    {
        System.out.println(eid);
        System.out.println(ename);
        System.out.println(job);
        System.out.println(sal);
    }

    /*public static void main(String[] args) {
        //Class is collection of attributes and behavior or we can say its blueprint.
        // Class is logical entities
        // Object is physical object
        // Without class there is no object
        // Object is an instance of a class
        // Animal---> Dog, Elephant, Horse etc..(Here we can term Animal as class and Elephant, Horse, and dogs are object of class)
        // Student--> Kim, David, Scott Etc(Objects of Class "Student")
        // Since class is a logical entity so it won't occupy any memory.
        // Class contains methods and variable but method can't hold method within it
        // If we will create variables in class we can access it throughout the class.
        // If we create variables inside a method we can access it in that particular method only
        // Variables which created inside a method is known as local method
        // There is no use of class until objects are not created
        // Objects can be created only within the main method
        Oops_Concept oopobject = new Oops_Concept();
        oopobject.eid= 102;
        oopobject.ename = "Brijesh Yadav";
        oopobject.job = "Software Tester";
        oopobject.sal   = 900000;
        oopobject.display();
        // We can create multiple objects with same class.
        Oops_Concept oopobject2  = new Oops_Concept();
        oopobject2.eid = 1023;
        oopobject2.ename = "Vignesh";
        oopobject2.job = "Software Tester";
        oopobject2.sal = 120000;
        oopobject2.display();
        // We can create n number of object from the same class.
        // Without main method we create class.
        // Which class includes main method is called main class.
        // From main class we can operate all other classes and objects
        // We can access all the classes through creating objects of those classes.


    }
    */
}
class MainClass
{
    public static void main(String[] args) {
        Oops_Concept mn = new Oops_Concept();
        mn.eid=103;
        mn.ename = "Brijesh Yadav";
        mn.job = "Software Tester";
        mn.sal  = 109939333;
        mn.display();
        System.out.println("____________________________");
        Oops_Concept mn1 = new Oops_Concept();
        mn1.eid=103;
        mn1.ename = "Vishal Dhoke";
        mn1.job = "Software Tester";
        mn1.sal  = 109933455;
        mn1.display();
        Oops_Concept mn2 = new Oops_Concept();
        // If we want to access a class from different package in such condition we have to import that package first



    }
}
