package Day11;

public class Methods {
    //There are pre-existing methods are available in java
    //Methods perform certain tasks for which they are made for
    /* 1. No Parameters     No Return Value
       2. No Parameters     Return Value    int len = s.length();
       3. Takes Parameters  No return value void m3(String name)
                                              {System.out.println(name);
                                              }
       4. Takes Parameters  Return Value    String sub = s.substring(2,3);
       5. If method is returning something we have to hold that in a variable
       6. If method has a return type we can print it as well using sopln.
       7. We can access the variable through the object reference variable.
       8. Using method we can assign the data.
       9. Third approach is USING Constructor
          Method name can be anything but constructor name is same to class name.
          Method may return and may not return any value but constructor never returns a value
          so, we don't specify any return type.
          Constructor is only for assigning data..
      10. For method we need to invoke it through object but constructor automatically invoked at the time of creation object.
      11. Most of the time we prefer constructor to initialize data.
      12. Same constructor we can create but parameters should be different.

      Constructor
      1. Default constructor
      2. Parameterized Constructor



     */
}
