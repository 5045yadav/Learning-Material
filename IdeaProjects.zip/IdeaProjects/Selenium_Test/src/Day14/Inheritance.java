package Day14;

public class Inheritance {
    /*
    Inheritance
    _________________________________________________________________________________
    Acquiring all the properties (Variables) & Behavior (Methods) from one class
    another class is called inheritance.

    Objective
    1. Reusability
    2. Avoid duplication

    There are 4 types of inheritance
    1. Single Inheritance
    2. Multilevel Inheritance.
    3. Hierarchy Inheritance
    4. Multiple Inheritance
      Multiple inheritance is not supported in java using class concept because
      when we try to access multiple parent classes it won't recognise for which class
      we are calling it.

      Method overriding
      --------------------------------------------------------------------------------
      Without inheritance we can't achieve method overriding
      In overriding we do change in implementation part

      For Example if a child gets property from his father, the house and all other
      things will be transferred him as it is but in that property he can do modification
      so for modification he needs that property first
      Like wise Inheritance comes first and then overriding comes in picture.


     */
}
