package Day15;
class Test{
    int x=100;
    
        }
public class Testfinalkeyword {
    public static void main(String[] args) {
        Test t = new Test();
        System.out.println(t.x);
        //t.x=200;// If we will apply final to x we won't be able to change the value
        System.out.println(t.x);
        /*
        If we make a method final we can't be able to override that method in child
        class.
        If we make a class final then we won't be able to extend it to child class
        if we don't want to inherit a class then we can make it final.

         */
    }
}
