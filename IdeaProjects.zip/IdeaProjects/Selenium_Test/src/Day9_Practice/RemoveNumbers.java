package Day9_Practice;

public class RemoveNumbers {
    public static void main(String[] args) {
        String s = "1234Brijesh12 Yadav";
        String cleanstring = s.replaceAll("[0-9]","");
        System.out.print(cleanstring);
    }
}
