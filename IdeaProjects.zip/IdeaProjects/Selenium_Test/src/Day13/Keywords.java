package Day13;

public class Keywords {
    static void main()
    {
        System.out.println("This is Main Method");
    }
    /*
    this keyword
    this keyword represents class/object variable

    There are 2 type of variables
    1. Class Variable/ instance variable
    2. local variable
    Class variable we can access anywhere but local variables can be accessed
    only within the method

     */
    static int a = 9;
    int x,y;// class variables or instance variable
    Keywords(int x, int y)
    {
     this.x=x;
     this.y=y;
     System.out.println(x+y);
    }

    public static void main(String[] args) {
        int a,b; //Local variable
        Keywords k =new Keywords(100,11);

/*
in java there is no concept of global variable because we can't declare any variable
outside the class
 */

        /*
        Static Keyword

        Static keyword can be applied for variables and methods
        Static variables
        Static methods

        non static variables
        non static methods
        just by writing static we can create a method or variable as static

        if we make a variable static, in that case it will become common variable
        across the objects.
        if we make any variable or method static, it will become common across the
        objects
        We can update that variable using any object and it will reflect in every object
        We can update it directly by class or any of the object.

        There are some restrictions
        When some data is common across multiple objects then only we can create that
        variable static

        There are some access level limitation
        Since static methods can directly access static method and static variable
        without creating any object.

        1. Static methods can access static stuff directly(Without object)
        2. Static methods can access non-static stuff through object.
        3. Non static methods can access everything directly.
        4. Through objects we can access non static methods and non
        static variables in static methods
        5. If we are changing the class name and method or variable is static
        and in the class we are accessing is also static in this condition we can access
        directly without creating object by specifying class name with method or variable
        These are the changes done by me

        in System.out.println();
        ------------------------
        System is predefined class out is static variable. println() is a method
        which belongs to printStream(Predefined class)

        public static void main(String []args)
        --------------------------------------
        public means this method is accessible throughout the project
        static means this method is common across all the classes all the object
        and JVM will be able to call it without any object
        void means it won't return any value
        String []args is array argument
        JVM always looks for this method to run




         */
        System.out.println(Keywords.a);
        main();
    }

}
