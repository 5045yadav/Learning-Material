package Day12;

public class Box {
    double width, height, depth;
    Box(double w, double h, double d)
    {
        width=w;
        height=h;
        depth=d;
    }
    Box(int w, int h, int d)
    {
        width=w;
        height=h;
        depth=d;
    }

double volume()
{
    return(width*height*depth);
}
    public static void main(String[] args) {
        Box b= new Box(10.1,12.2,13.4);
        System.out.println(b.volume());

    }
}
