package Day12;

public class Polymorphism {
    /*
    Polymorphism
    One thing can have many forms

    We can achieve this using overloading concept
    overloading is applicable for method and constructor

    In method overloading 4 rules are applicable
    1). Method names should be same.
    2). Number of parameters should be different.
    3). Data type of parameters should be same.
    4). Order of parameters should be different.
    5). Return type can be different in method overloading
     */
    void add(int a,int b)
    {
        System.out.println(a+b);
    }
    void add (int a, int b, int c)
    {
        System.out.println(a+b+c);
    }
    void add  (int a, int b, int c, int d)
    {
        System.out.println(a+b+c+d);
    }

    public static void main(String[] args) {
        Polymorphism  p = new Polymorphism();
        p.add(1,2,4,7);
        /*
       Now Constructor Overloading
       ---------------------------

         */
    }
}
