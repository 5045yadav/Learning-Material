package Day12;

public class Encapsulation {

    /*
    Encapsulation
    ----------------------------------------------------------------------------------
    Wrapping up of data and methods in to single unit(Class)

   To achieve encapsulation we should follow following rule
   1. All variables should be private.
   2. For every variable there should be 2 methods(Get & Set)
   3. Variables can be operated only through methods.

   Can we overload main method?
   ----------------------------
   Yes we can overload it by following overloading rules



     */
}
